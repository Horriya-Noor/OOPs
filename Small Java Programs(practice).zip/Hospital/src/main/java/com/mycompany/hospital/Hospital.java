/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.hospital;

/**
 *
 * @author HP
 */
// Hospital.java
import java.util.ArrayList;
import java.util.List;

public class Hospital {
    private String name;
    private String location;
    private List<Doctors> doctors;

    public Hospital(String name, String location) {
        this.name = name;
        this.location = location;
        this.doctors = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public String getLocation() {
        return location;
    }

    public List<Doctors> getDoctors() {
        return doctors;
    }

    public void addDoctor(Doctors doctor) {
        this.doctors.add(doctor);
        System.out.println(doctor.getName() + " added to " + name);
    }

    public void showAllDoctors() {
        System.out.println("--- Doctors at " + name + " ---");
        if (doctors.isEmpty()) {
            System.out.println("No doctors currently working here.");
        } else {
            for (Doctors doctor : doctors) {
                System.out.println("- " + doctor.getName() + " (" + doctor.getSpecialization() + ")");
            }
        }
        System.out.println("--------------------------");
    }

    public void showHospitalInfo() {
        System.out.println("--- Hospital Information ---");
        System.out.println("Name: " + name);
        System.out.println("Location: " + location);
        System.out.println("Number of Doctors: " + doctors.size());
        System.out.println("----------------------------");
    }
}