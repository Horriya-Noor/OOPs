/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospital;

/**
 *
 * @author HP
 */
public class Patient {
    private String namo;
    private int ageo;
    private String diseasea;

    public Patient(String name, int age, String disease) {
        this.namo = name;
        this.ageo = age;
        this.diseasea = disease;
    }

    public String getName() {
        return namo;
    }

    public int getAge() {
        return ageo;
    }

    public String getDisease() {
        return diseasea;
    }

    public void displayPatientInfo() {
        System.out.println("  Patient Name: " + namo);
        System.out.println("  Age: " + ageo);
        System.out.println("  Disease: " + diseasea);
    }
}
    

