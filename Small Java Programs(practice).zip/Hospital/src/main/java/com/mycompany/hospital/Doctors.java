/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospital;

/**
 *
 * @author HP
 */

// Doctor.java

import java.util.ArrayList;
import java.util.List;

public class Doctors {
    private String nam;
    private String specialization;
    private int experience_Years;
    private List<Patient> patients;

    public Doctors(String name, String specialization, int experienceYears) {
        this.nam = name;
        this.specialization = specialization;
        this.experience_Years = experienceYears;
        this.patients = new ArrayList<>();
    }

    public String getName() {
        return nam;
    }

    public String getSpecialization() {
        return specialization;
    }

    public int getExperienceYears() {
        return experience_Years;
    }

    public List<Patient> getPatients() {
        return patients;
    }

    public void addPatient(Patient patient) {
        this.patients.add(patient);
        System.out.println(nam + " added patient: " + patient.getName());
    }

    public void showDoctorInfo() {
        System.out.println("--- Doctor Information ---");
        System.out.println("Name: " + nam);
        System.out.println("Specialization: " + specialization);
        System.out.println("Experience: " + experience_Years + " years");
        if (!patients.isEmpty()) {
            System.out.println("Patients:");
            for (Patient patient : patients) {
                patient.displayPatientInfo();
            }
        } else {
            System.out.println("No patients assigned yet.");
        }
        System.out.println("--------------------------");
    }
}