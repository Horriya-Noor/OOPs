/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospital;

/**
 *
 * @author HP
 */
public class MainSystem {

    public static void main(String[] args) {
        // Create some patients
        Patient patient1 = new Patient("Alice", 30, "Flu");
        Patient patient2 = new Patient("Bob", 45, "High Blood Pressure");
      

        // Create some doctors
        Doctors drAna = new Doctors("Ana Saad", "Cardiologist", 10);
        Doctors drAlice = new Doctors("Alice Jimi", "Pediatrician", 5);
        Doctors drLili = new Doctors("Lili Andrew", "Surgeon", 15);

        // Create some hospitals
        Hospital cityHospital = new Hospital("City General Hospital", "Downtown");
        Hospital centralClinic = new Hospital("Central Medical Clinic", "Uptown");

        // Doctors working in City Hospital
        cityHospital.addDoctor(drAna);
        cityHospital.addDoctor(drLili);

        // Doctor working in Central Clinic
        centralClinic.addDoctor(drAlice);
        centralClinic.addDoctor(drAna); // Dr. Smith works in both hospitals

        // Doctor adds patients
        drAna.addPatient(patient1);
        drAlice.addPatient(patient2);

        // Show doctor information
        drAna.showDoctorInfo();
        drLili.showDoctorInfo();

        // Show hospital information and doctors
        cityHospital.showHospitalInfo();
        cityHospital.showAllDoctors();

        centralClinic.showHospitalInfo();
        centralClinic.showAllDoctors();
    }
}
    
