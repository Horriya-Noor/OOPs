/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.patterngenerator;

/**
 *
 * @author HP
 */

import java.util.Scanner;

public class PatternGenerator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter your full name: ");
        String nam = scanner.nextLine();
        scanner.close();

        String[] names = nam.split(" ");
        String f_name = names[0];
        String l_name = names[1];

        System.out.println(generatePattern(f_name, true));
        System.out.println(generatePattern(f_name, false));

        System.out.println(generatePattern(l_name, true));
        System.out.println(generatePattern(l_name, false));
    }

   
    public static String generatePattern(String name, boolean reverse) {
        StringBuilder pattern = new StringBuilder();

        if (reverse) {
            for (int i = name.length(); i > 0; i--) {
                pattern.append(name.substring(0, i)).append("\n");
            }
        } else {
            for (int i = 1; i <= name.length(); i++) {
                pattern.append(name.substring(0, i)).append("\n");
            }
        }

        return pattern.toString();
    }
}


