import java.util.Scanner;

public class Caesar {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter your full name: ");
        String fullName = scanner.nextLine();

        String[] names = fullName.split(" ");

        if (names.length >= 2) {
            String firstName = names[0].toUpperCase();
            String lastName = names[1].toUpperCase();

            Makepattern(firstName);
          Makepattern(lastName);
        } else {
            System.out.println("Please enter both first and last names.");
        }

        scanner.close();
    }

    private static void Makepattern(String name) {
        
        for (int i = name.length(); i > 0; i--) {
            System.out.println(name.substring(0, i));
        }

        
        for (int i = 2; i <= name.length(); i++) {
            System.out.println(name.substring(0, i));
        }
    }
}