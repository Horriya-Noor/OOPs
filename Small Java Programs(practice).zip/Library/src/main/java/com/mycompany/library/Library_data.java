/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.library;

/**
 *
 * @author HP
 */
public class Library_data {
    public String name;
    public String location;
    public String list;

public String lib (String n ,String loc , String list ){
    this.name  = n ;
    this.location= loc ;
    this.list = list ;
    
}

public void libd_ata (){
    System.out.println( "Name of library" + lib.n);
    System.out.println( "Location of Library " + lib.loc);
    System.out.println( "List of Books in Library" + lib.list);
}
    
}
