/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.library;

/**
 *
 * @author HP
 */
public class Books {
    
public String title;
public String author;
public String isbn_number;

public String book (String t ,String a , String isbn ){
    this.title  = t ;
    this.author = a ;
    this.isbn_number = isbn ;
    
}

public void add_Bookdata (){
    System.out.println( "Title of Book" + book.t);
    System.out.println( "Author of Book" + book.a);
    System.out.println( "ISBN number of Book" + book.isbn);
}
    
}
