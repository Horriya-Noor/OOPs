/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.library;

/**
 *
 * @author HP
 */
import java.util.Arraylist;

public class Library {

    public static void main(String[] args) {
        
     Books Book = new Books();
     Library_data Lib_data = new Library_data() ;
     
     Book Arraylist<add_Bookdata> book;
     Library Arraylist<libd_ata ()> data;
     
     

     
     
    }
}
