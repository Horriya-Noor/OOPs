/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.candycrush;

/**
 *
 * @author HP
 */

import java.util.Scanner;

class CandyCrush {
    private String namo;
    private int score;
    private int levelo;

    // Constructor
    public CandyCrush(String playerName) {
        this.namo = playerName;
        this.score = 0;
        this.levelo = 1;
    }

    // Getters
    public String getPlayerName() {
        return namo;
    }

    public int getPlayerScore() {
        return score;
    }

    public int getPlayerLevel() {
        return levelo;
    }

    // using Setters
    public void setPlayerScore(int score) {
        this.score = score;
    }

    public void setPlayerLevel(int level) {
        this.levelo = level;
    }

    // Player actions
    public void playerAction(String action) {
        
        System.out.println("match candies");
        System.out.println("clear a row");
        System.out.println("complete a level");
        System.out.println("Exit");
        switch (action) {
            case "1":
                setPlayerScore(getPlayerScore() + 20);
                break;
            case "2":
                setPlayerScore(getPlayerScore() + 30);
                break;
            case "3":
                setPlayerLevel(getPlayerLevel() + 1);
                break;
            default:
                System.out.println("Invalid action!");
                return;
        }
        displayProgress();
    }

    // Display player progress
    public void displayProgress() {
        System.out.println("Player: " + getPlayerName());
        System.out.println("Score: " + getPlayerScore());
        System.out.println("Level: " + getPlayerLevel());
    }

    // Main method
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter player name: ");
        String playerName = scanner.nextLine();
        CandyCrush player = new CandyCrush(playerName);

       
            System.out.println("\nChoose an action:");
            System.out.println("1. Match candies");
            System.out.println("2. Clear a row");
            System.out.println("3. Complete a level");
            System.out.println("4. Exit");
                     
            System.out.print("Enter action: ");
            String action = scanner.nextLine();
            player.playerAction(action);
        }
       
    }
