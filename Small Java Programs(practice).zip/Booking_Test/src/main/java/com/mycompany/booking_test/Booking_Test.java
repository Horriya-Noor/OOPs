/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.booking_test;

/**
 *
 * @author HP
 */
import java.util.Scanner;

public class Booking_Test {
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        
        System.out.println("Enter the name for train booking");
        String trainName=  scanner.nextLine();
        
        System.out.println("Enter the date for train booking");
        String trainDate=  scanner.nextLine();
        
        Booking trainbooking= new Train_Booking(trainName,trainDate);
        trainbooking.confirmBooking();
        
        System.out.println("Enter the name for flight booking");
        String flightName= scanner.nextLine();
        
        System.out.println("Enter the date for flight booking");
        String flightDate=  scanner.nextLine();
        
        Booking flightbooking= new Flight_Booking(flightName, flightDate);
        flightbooking.confirmBooking();
        
    }
    
}
