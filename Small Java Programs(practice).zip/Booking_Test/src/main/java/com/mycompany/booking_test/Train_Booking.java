/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.booking_test;

/**
 *
 * @author HP
 */

class Train_Booking extends Booking {
    public Train_Booking(String customerName, String date) {
        super(customerName, date);
    }

    @Override
    void confirmBooking() {
        System.out.println("Welcome aboard!!!!");
        System.out.println("Your tickets are confirmed for Train.");
        System.out.println( "Customer: " + customerName );
        System.out.println(" Date: " + date);
    }
}