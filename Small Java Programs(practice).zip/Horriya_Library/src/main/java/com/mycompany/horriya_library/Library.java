/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.horriya_library;

/**
 *
 * @author HP
 */
import java.util.ArrayList;
import java.util.Iterator;

class Library {
    private final ArrayList<Book> books;

    public Library() {
        this.books = new ArrayList<>();
    }

    public void addBook(final Book book) {
        this.books.add(book);
        System.out.println("Book added successfully.");
    }

    public void removeBook(final int bookID) {
        final Iterator<Book> iterator = this.books.iterator();
        while (iterator.hasNext()) {
            final Book book = iterator.next();
            if (book.bookID == bookID) {
                iterator.remove();
                System.out.println("Book with ID " + bookID + " removed.");
                return;
            }
        }
        System.out.println("Book with ID " + bookID + " not found.");
    }

    public void displayAllBooks() {
        if (this.books.isEmpty()) {
            System.out.println("Library is empty.");
            return;
        }

        System.out.println("All Books in the Library:");
        for (final Book book : this.books) {
            book.displayBook();
            System.out.println("---");
        }
    }
}