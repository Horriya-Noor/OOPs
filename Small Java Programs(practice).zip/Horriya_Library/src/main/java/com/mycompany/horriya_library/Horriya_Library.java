/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.horriya_library;

/**
 *
 * @author HP
 */
public class Horriya_Library {

    public static void main(String[] args) {
        Library library = new Library();

        Book book1 = new Book(101, "The Hitchhiker's Guide to the Galaxy", "Douglas Adams");
        Book book2 = new Book(102, "Pride and Prejudice", "Jane Austen");
        Book book3 = new Book(103, "1984", "George Orwell");

        library.addBook(book1);
        library.addBook(book2);
        library.addBook(book3);

        System.out.println("\n--- Displaying All Books ---");
        library.displayAllBooks();

        System.out.println("\n--- Removing Book with ID 102 ---");
        library.removeBook(102);

        System.out.println("\n--- Displaying Updated Book List ---");
        library.displayAllBooks();

        System.out.println("\n--- Removing Book with ID 104 (Non existant) ---");
        library.removeBook(104);

    }
}
