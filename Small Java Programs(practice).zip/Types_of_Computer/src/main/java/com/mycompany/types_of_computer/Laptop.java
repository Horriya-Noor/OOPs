/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.types_of_computer;

/**
 *
 * @author HP
 */
    class Laptop extends Comp {
    public double batteryPercentage;

    public Laptop(String model, double batteryPercentage) {
        super(model);
        this.batteryPercentage = batteryPercentage;
    }

    @Override
    public void runProgram(String programName) {
        System.out.println("Laptop (" + model + "): Running program '" + programName + "' on battery (" + String.format("%.2f", batteryPercentage) + "% remaining)...");
        // Laptop-specific behavior
        System.out.println("Optimizing for battery usage.");
        System.out.println("Executing program with potential performance throttling.");
    }

    public void displayBattery() {
        System.out.println("Battery level is " + String.format("%.2f", batteryPercentage) + "%.");
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Battery: " + String.format("%.2f", batteryPercentage) + "%");
    }
}

    

