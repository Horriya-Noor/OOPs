/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.types_of_computer;

/**
 *
 * @author HP
 */
public class Comp {
    public String model;

    public Comp(String model) {
        this.model = model;
    }

    public void runProgram(String programName) {
        System.out.println("Computer (" + model + "): Running program '" + programName + "'...");
        // Default behavior for a generic computer
        System.out.println("Performing basic computations.");
    }

    public void displayInfo() {
        System.out.println("Model: " + model);
    }
    
}
