/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.types_of_computer;

/**
 *
 * @author HP
 */

import java.util.ArrayList;
import java.util.List;

public class Types_of_Computer {

    // Inner class representing a computer with various attributes
    public static class Computer {
        private String model;
        private String processor;
        private int ram;
        private int storage;
        private double price;

        // Constructor to initialize the attributes of a Computer object
        public Computer(String model, String processor, int ram, int storage, double price) {
            this.model = model;
            this.processor = processor;
            this.ram = ram;
            this.storage = storage;
            this.price = price;
        }

        // Method to display the specifications of the computer
        public void displaySpecs() {
            System.out.println("Model: " + model);
            System.out.println("Processor: " + processor);
            System.out.println("RAM: " + ram + "GB");
            System.out.println("Storage: " + storage + "GB");
            System.out.println("Price: $" + price);
            System.out.println("------------------------");
        }
        public String getModel()
        {
            return model;
        }
    }


    public static class ComputerSimulationWithoutGettersSetters {
 
        private List<Computer> computers;

        public ComputerSimulationWithoutGettersSetters() {
            this.computers = new ArrayList<>();
        }

        public void addComputer(String model, String processor, int ram, int storage, double price) {
            // Corrected:  Removed 'this' because the method is not static.
            Computer computer = new Computer(model, processor, ram, storage, price);
            this.computers.add(computer); // Added 'this'
        }

        public void displayAllComputers() {
            if (computers.isEmpty()) {
                System.out.println("No computers added yet.");
            } else {
                System.out.println("--- Computer Inventory ---");
                for (Computer computer : computers) {
                    computer.displaySpecs();
                }
            }
        }
    }


    public static void main(String[] args) {

        ComputerSimulationWithoutGettersSetters simulation = new ComputerSimulationWithoutGettersSetters();

        simulation.addComputer("Dell XPS 15", "Intel i7", 16, 512, 1799.99);
        simulation.addComputer("MacBook Pro 16", "Apple M1 Pro", 16, 1024, 2499.99);
        simulation.addComputer("HP Spectre x360", "Intel i5", 8, 256, 1299.99);


        simulation.displayAllComputers();
        
     
        Computer[] computerArray = new Computer[3];
        computerArray[0] = new Computer("Lenovo ThinkPad", "AMD Ryzen 7", 32, 512, 1999.99);
        computerArray[1] = new Computer("Asus ROG Zephyrus", "Nvidia RTX 3080", 32, 1024, 2999.99);
        computerArray[2] = new Computer("Microsoft Surface Laptop", "Intel i7", 16, 512, 1499.99);
        
        System.out.println("\n--- Computer Array Specs ---");
        for (Computer computer : computerArray){
            computer.displaySpecs();
        }
        

        System.out.println("First Computer Model: " + computerArray[0].getModel());

    }
}
