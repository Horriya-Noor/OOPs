/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.device_controller;

/**
 *
 * @author HP
 */
interface RemoteControl {
    void turnOn();
    void turnOff();
    
}
class TV implements RemoteControl {

    @Override
    public void turnOn() {
        System.out.println("TV is Turned ON"); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void turnOff() {
        System.out.println("TV is Turned OFF"); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}

class Light implements RemoteControl {

    @Override
    public void turnOn() {
        System.out.println("Light is Turned ON"); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void turnOff() {
        System.out.println("Light is Turned OFF"); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
    


class Speaker implements RemoteControl {

    @Override
    public void turnOn() {
        System.out.println("Speaker is Turned ON"); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void turnOff() {
        System.out.println("Speaker is Turned OFF"); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
    


