/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.device_controller;

/**
 *
 * @author HP
 */
public class Device_Controller {

    public static void main(String[] args) {
        RemoteControl device;
        
        device = new TV();
        device.turnOn();
        device.turnOff();
       
        device = new Light();
        device.turnOn();
        device.turnOff();
        
        device = new Speaker();
        device.turnOn();
        device.turnOff();
       
       
        
    }
}
