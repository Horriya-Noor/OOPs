/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.booking;

/**
 *
 * @author HP
 */
abstract class Booking {
    String CustomerName;
    String Date;

  
    public Booking(String CustomerName, String Date) {
        this.CustomerName = CustomerName;
        this.Date = Date;
    }


    abstract void confirmBooking();
}