package com.mycompany.data;

import java.util.Scanner;

public class Practice {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Your secret message: ");
        String message = scanner.nextLine();

        System.out.print("Your secret key: ");
        int KEY = scanner.nextInt();

        StringBuilder alteredMessage = new StringBuilder();

        for (char c : message.toCharArray()) {
            if (Character.isLetter(c)) {
                char base = Character.isLowerCase(c) ? 'a' : 'A';
                int originalAlphabetPosition = c - base;
                int alteredAlphabetPosition = (originalAlphabetPosition + KEY) % 26;
                if (alteredAlphabetPosition < 0) {
                    alteredAlphabetPosition += 26;
                }
                char alteredChar = (char) (base + alteredAlphabetPosition);
                alteredMessage.append(alteredChar);
            } else {
                alteredMessage.append(c);
            }
        }

        System.out.println("The altered message: " + alteredMessage.toString());

        scanner.close();
    }
}