/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.data;

/**
 *
 * @author HP
 */
import java.util.Scanner;

// Department Class
class Department {
    private String departmentName;
    private String departmentHead;

    // Default Constructor
    public Department() {
        this.departmentName = "Unknown";
        this.departmentHead = "Unknown";
    }

    // Parameterized Constructor
    public Department(String departmentName, String departmentHead) {
        this.departmentName = departmentName;
        this.departmentHead = departmentHead;
    }

    // Copy Constructor
    public Department(Department other) {
        this.departmentName = other.departmentName;
        this.departmentHead = other.departmentHead;
    }

    // Display Method
    public void display(Student student) {
        System.out.println("Department Name: " + departmentName);
        System.out.println("Department Head: " + departmentHead);
        System.out.println("Student Name: " + student.getStudentName());
        System.out.println("Student Roll Number: " + student.getRollNumber());
    }

    // Getters and Setters
    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public String getDepartmentHead() {
        return departmentHead;
    }

    public void setDepartmentHead(String departmentHead) {
        this.departmentHead = departmentHead;
    }
}

// Student Class
class Student {
    private String studentName;
    private int rollNumber;
    private Department department;

    // Default Constructor
    public Student() {
        this.studentName = "Unknown";
        this.rollNumber = 0;
        this.department = new Department();
    }

    // Parameterized Constructor
    public Student(String studentName, int rollNumber, Department department) {
        this.studentName = studentName;
        this.rollNumber = rollNumber;
        this.department = new Department(department); // Using copy constructor
    }

    // Copy Constructor
    public Student(Student other) {
        this.studentName = other.studentName;
        this.rollNumber = other.rollNumber;
        this.department = new Department(other.department);
    }

    // Getters and Setters
    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public int getRollNumber() {
        return rollNumber;
    }

    public void setRollNumber(int rollNumber) {
        this.rollNumber = rollNumber;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }
}

// Main Class
public class Data{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Taking Department Details
        System.out.print("Enter Department Name: ");
        String deptName = scanner.nextLine();
        System.out.print("Enter Department Head: ");
        String deptHead = scanner.nextLine();
        Department department = new Department(deptName, deptHead);

        // Taking Student Details
        System.out.print("Enter Student Name: ");
        String studentName = scanner.nextLine();
        System.out.print("Enter Roll Number: ");
        int rollNumber = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        // Creating Student Object
        Student student = new Student(studentName, rollNumber, department);

        // Displaying Details
        department.display(student);

        scanner.close();
    }
}