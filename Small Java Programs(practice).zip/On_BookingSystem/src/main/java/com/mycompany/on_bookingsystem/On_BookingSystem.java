/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.on_bookingsystem;

/**
 *
 * @author HP
 */
abstract class On_BookingSystem {

   protected String customerName;
   protected String date;

   
   public On_BookingSystem(String customerName, String date) {
       this.customerName = customerName;
       this.date = date;
 }
   
   abstract void confirmBooking();
}
