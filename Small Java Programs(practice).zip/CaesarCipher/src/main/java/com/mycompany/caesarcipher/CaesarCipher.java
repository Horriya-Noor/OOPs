/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.caesarcipher;

/**
 *
 * @author HP
 */
import java.util.Scanner;

public class CaesarCipher {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

     
        System.out.print("Your secret message: ");
        String message = scanner.nextLine();


        System.out.print("Your secret key: ");
        int key = scanner.nextInt();
        scanner.close();

        String encoded_Message = encrypt_Message(message, key);

        System.out.println("The encoded message: " + encoded_Message);
    }

  
    public static String encrypt_Message(String message, int key) {
        StringBuilder encoded_Message = new StringBuilder();

        for (char c : message.toCharArray()) {
            if (Character.isLetter(c)) {
                char base = Character.isUpperCase(c) ? 'A' : 'a';
                encoded_Message.append((char) ((c - base + key) % 26 + base));
            } else {
                encoded_Message.append(c);
            }
        }

        return encoded_Message.toString();
    }
}


