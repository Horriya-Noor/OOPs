/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.horriya_student;

/**
 *
 * @author HP
 */
public class Horriya_Student {
   public class StudentCourseManagementSystem {
    public static void main(final String... args) { // Using varargs
        final Student student1 = new Student(101, "Alice");
        final Student student2 = new Student(102, "Bob");

        final Course course1 = new Course("CS101", "Introduction to Programming");
        final Course course2 = new Course("MA201", "Linear Algebra");
        final Course course3 = new Course("PH101", "Physics I");

        student1.enrollCourse(course1);
        student1.enrollCourse(course2);
        student2.enrollCourse(course2);
        student2.enrollCourse(course3);

        System.out.println("\n--- Student Details and Enrolled Courses ---");
        displayStudentAndCourses(student1); //Using a method to display the student and courses.

        System.out.println("\n--- Student Details and Enrolled Courses ---");
        displayStudentAndCourses(student2); //Using a method to display the student and courses.
    }

    // Method to display student and their enrolled courses.
    private static void displayStudentAndCourses(final Student student) {
        student.displayStudent();
        student.displayEnrolledCourses();
    } } }
