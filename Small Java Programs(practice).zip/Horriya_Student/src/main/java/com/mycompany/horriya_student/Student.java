/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.horriya_student;

/**
 *
 * @author HP
 */

 import java.util.ArrayList;

class Student {
    private final int studentID;
    private final String name;
    private final ArrayList<Course> enrolledCourses;

    public Student(final int studentID, final String name) {
        this.studentID = studentID;
        this.name = name;
        this.enrolledCourses = new ArrayList<>();
    }

    public void displayStudent() {
        System.out.println("Student ID: " + this.studentID);
        System.out.println("Name: " + this.name);
    }

    public void enrollCourse(final Course course) {
        this.enrolledCourses.add(course);
        System.out.println(this.name + " enrolled in " + course.getCourseName());
    }

    public void displayEnrolledCourses() {
        if (this.enrolledCourses.isEmpty()) {
            System.out.println(this.name + " is not enrolled in any courses.");
            return;
        }

        System.out.println("Enrolled Courses for " + this.name + ":");
        for (final Course course : this.enrolledCourses) {
            course.displayCourse();
        }
    }

    public int getStudentID() {
        return this.studentID;
    }
}
