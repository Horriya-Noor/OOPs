/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.horriya_student;

/**
 *
 * @author HP
 */
class Course {
    private final String courseCode;
    private final String courseName;

    public Course(final String courseCode, final String courseName) {
        this.courseCode = courseCode;
        this.courseName = courseName;
    }

    public void displayCourse() {
        System.out.println("Course Code: " + this.courseCode);
        System.out.println("Course Name: " + this.courseName);
    }

    public String getCourseName() {
        return this.courseName;
    }

    public String getCourseCode() {
        return this.courseCode;
    }
}
