/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.dishes;

/**
 *
 * @author HP
 */

import java.util.scanner;

public class Dishes {

    pubic void print()
    {
         int local = 0;
         
        
    } 
}
