/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.books;

/**
 *
 * @author HP
 */
public class Main {
    public static void main(String[] args) {
        
        Books book1 = new Books("Shadow and Bones ");
        Books book2 = new Books("Six of Crows", 2017 );
        Books book3 = new Books("Crooked Kingdom", 2012, " Rs. 1100");

       
        System.out.println("Book # 1 : ");
        book1.printDetails();
        System.out.println("Book # 2 :");
        book2.printDetails();
        System.out.println("Book # 3 :");
        book3.printDetails();
    }
}
    
