/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.books;

/**
 *
 * @author HP
 */
    
public class Books {
    private String n;
    private int y;
    private String p;

   
    public Books(String name) {
        this.n = name;
    }

   
    public Books(String name, int year) {
        this.n = name;
        this.y = year;
    }

    
    public Books(String name, int year, String price) {
        this.n = name;
        this.y = year;
        this.p = price;
    }

    
    public void printDetails() {
        System.out.println("Book Name: " + n); 
        System.out.println("Year of Publication: " + y); 
        System.out.println("Price: " + p);
            }
        }
        
 