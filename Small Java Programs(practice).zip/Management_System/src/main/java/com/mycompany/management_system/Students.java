/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.management_system;

/**
 *
 * @author HP
 */
    import java.util.ArrayList;
import java.util.List;

// Student class
class Student {
    private String name;
    private String studentID;
    private String emailID;

    public Student(String name, String studentID, String emailID) {
        this.name = name;
        this.studentID = studentID;
        this.emailID = emailID;
    }

    public String getName() {
        return name;
    }

    public String getStudentID() {
        return studentID;
    }

    public String getEmailID() {
        return emailID;
    }

    public void submitAssignment() {
        System.out.println(name + " (ID: " + studentID + ") has submitted the assignment.");
    }

    public void displayStudentInfo() {
        System.out.println("--- Student Information ---");
        System.out.println("Name: " + name);
        System.out.println("Student ID: " + studentID);
        System.out.println("Email ID: " + emailID);
        System.out.println("---------------------------");
    }
}

// Course class
class Course {
    private String courseTitle;
    private String courseCode;
    private List<Student> enrolledStudents;

    public Course(String courseTitle, String courseCode) {
        this.courseTitle = courseTitle;
        this.courseCode = courseCode;
        this.enrolledStudents = new ArrayList<>();
    }

    public String getCourseTitle() {
        return courseTitle;
    }

    public String getCourseCode() {
        return courseCode;
    }

    public List<Student> getEnrolledStudents() {
        return enrolledStudents;
    }

    public void enrollStudent(Student student) {
        enrolledStudents.add(student);
        System.out.println(student.getName() + " enrolled in " + courseTitle);
    }

    public void removeStudent(String studentID) {
        Student studentToRemove = null;
        for (Student student : enrolledStudents) {
            if (student.getStudentID().equals(studentID)) {
                studentToRemove = student;
                break;
            }
        }
        if (studentToRemove != null) {
            enrolledStudents.remove(studentToRemove);
            System.out.println(studentToRemove.getName() + " removed from " + courseTitle);
        } else {
            System.out.println("Student with ID " + studentID + " not found in " + courseTitle);
        }
    }

    public void displayEnrolledStudents() {
        if (enrolledStudents.isEmpty()) {
            System.out.println("No students enrolled in " + courseTitle);
            return;
        }
        System.out.println("--- Enrolled Students in " + courseTitle + " ---");
        for (Student student : enrolledStudents) {
            System.out.println("Name: " + student.getName() + ", ID: " + student.getStudentID());
        }
        System.out.println("---------------------------------------");
    }

    public void displayCourseInfo() {
        System.out.println("--- Course Information ---");
        System.out.println("Course Title: " + courseTitle);
        System.out.println("Course Code: " + courseCode);
        System.out.println("Number of Enrolled Students: " + enrolledStudents.size());
        System.out.println("--------------------------");
    }
}

