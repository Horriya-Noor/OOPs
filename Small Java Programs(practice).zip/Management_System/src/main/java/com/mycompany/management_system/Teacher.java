/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.management_system;

/**
 *
 * @author HP
 */
public class Teacher {
    
    public void enroll_Student(Course course, Student student) {
        course.enrollStudent(student);
    }

    public void remove__Student(Course course, String studentID) {
        course.removeStudent(studentID);
    }

    public void displayEnroll_Student(Course course) {
        course.displayEnrolledStudents();
    }

    public void displayCourse_Details(Course course) {
        course.displayCourseInfo();
    }
}


    

