/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.management_system;

/**
 *
 * @author HP
 */
public class Management_System {

    public static void main(String[] args) {
        // Create some students
        Student student1 = new Student("Ana Fish", "001", "ana.fish@example.com");
        Student student2 = new Student("Cheery Red", "002", "red.cheery@example.com");
        Student student3 = new Student("Smily James", "003", "smily.james@example.com");

        // Create a course
        Course javaProgramming = new Course("Java Programming", "CS101");

        // Create a teacher
        Teacher teacher = new Teacher();

        // Teacher enrolls students in the course
        teacher.enroll_Student(javaProgramming, student1);
        teacher.enroll_Student(javaProgramming, student2);

        System.out.println();

        // Display enrolled students in the course
        teacher.displayEnroll_Student(javaProgramming);

        System.out.println();

        // Display course information
        teacher.displayCourse_Details(javaProgramming);

        System.out.println();

        // Student submits an assignment
        student1.submitAssignment();

        System.out.println();

        // Display student information
        student2.displayStudentInfo();

        System.out.println();

        // Teacher removes a student from the course
        teacher.remove__Student(javaProgramming, "S1002");

        System.out.println();

        // Display updated enrolled students
        teacher.displayEnroll_Student (javaProgramming);
    }}


