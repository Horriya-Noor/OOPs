/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.computer;

/**
 *
 * @author HP
 */
public class Computer {
    
    private String brand;
    private Processor processor;
    private RAM ram;
    private boolean isRunningProgram;

    public Computer(String brand, String processorModel, double processorSpeedGHz, int processorCores,
                    int ramCapacityGB, int ramSpeedMHz) {
        this.brand = brand;
        this.processor = new Processor(processorModel, processorSpeedGHz, processorCores);
        this.ram = new RAM(ramCapacityGB, ramSpeedMHz);
        this.isRunningProgram = false;
    }

    public String getBrand() {
        return brand;
    }

    public Processor getProcessor() {
        return processor;
    }

    public RAM getRam() {
        return ram;
    }

    public void startProgram() {
        isRunningProgram = true;
        System.out.println(brand + " computer started running a program.");
    }

    public void stopProgram() {
        isRunningProgram = false;
        System.out.println(brand + " computer stopped running the program.");
    }

    public void displayComputerSpecs() {
        System.out.println("--- Computer Specs ---");
        System.out.println("Brand: " + brand);
        processor.displayProcessorSpecs();
        ram.displayRAMSpecs();
        System.out.println("----------------------");
    }

    public void displayRunningStatus() {
        if (isRunningProgram) {
            System.out.println(brand + " computer is currently running a program.");
        } else {
            System.out.println(brand + " computer is not running any program.");
        }
    }
}

