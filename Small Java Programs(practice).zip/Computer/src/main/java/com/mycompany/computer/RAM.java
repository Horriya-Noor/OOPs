/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.computer;

/**
 *
 * @author HP
 */
public class RAM {

    private int capacityGB;
    private int speedMHz;

    public RAM(int capacityGB, int speedMHz) {
        this.capacityGB = capacityGB;
        this.speedMHz = speedMHz;
    }

    public int getCapacityGB() {
        return capacityGB;
    }

    public int getSpeedMHz() {
        return speedMHz;
    }

    public void displayRAMSpecs() {
        System.out.println("--- RAM Specs ---");
        System.out.println("Capacity: " + capacityGB + " GB");
        System.out.println("Speed: " + speedMHz + " MHz");
        System.out.println("-----------------");
    }
}
    

