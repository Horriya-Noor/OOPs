/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.computer;

/**
 *
 * @author HP
 */
public class Processor {
 
    private String model;
    private double speedGHz;
    private int numCores;

    public Processor(String model, double speedGHz, int numCores) {
        this.model = model;
        this.speedGHz = speedGHz;
        this.numCores = numCores;
    }

    public String getModel() {
        return model;
    }

    public double getSpeedGHz() {
        return speedGHz;
    }

    public int getNumCores() {
        return numCores;
    }

    public void displayProcessorSpecs() {
        System.out.println("--- Processor Specs ---");
        System.out.println("Model: " + model);
        System.out.println("Speed: " + speedGHz + " GHz");
        System.out.println("Number of Cores: " + numCores);
        System.out.println("-----------------------");
    }
}
    

