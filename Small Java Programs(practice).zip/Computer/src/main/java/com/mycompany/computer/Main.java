/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.computer;

/**
 *
 * @author HP
 */
public class Main {
    public static void main(String[] args) {
        // Create a computer object
        Computer myComputer = new Computer("Dell", "Intel Core i7", 3.2, 8, 16, 3200);

        // Display computer specifications
        myComputer.displayComputerSpecs();

        System.out.println();

        // Display processor specifications directly
        myComputer.getProcessor().displayProcessorSpecs();

        System.out.println();

        // Display RAM specifications directly
        myComputer.getRam().displayRAMSpecs();

        System.out.println();

        // Check and display running status
        myComputer.displayRunningStatus();

        System.out.println();

        // Start a program
        myComputer.startProgram();

        System.out.println();

        // Check and display running status again
        myComputer.displayRunningStatus();

        System.out.println();

        // Stop the program
        myComputer.stopProgram();

        System.out.println();

        // Check and display running status one last time
        myComputer.displayRunningStatus();
    }
}
    

