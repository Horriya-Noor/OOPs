/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.banking_system;

/**
 *
 * @author HP
 */
public class Banking_System {

    public static void main(String[] args) {
        SavingsAccount savingsAccount = new SavingsAccount("SA123", 1000, 5);
        CurrentAccount currentAccount = new CurrentAccount("CA456", 2000, 500);
        FixedDepositAccount fixedDepositAccount = new FixedDepositAccount("FD789", 5000, 12);

        System.out.println("Savings Account Details:");
        savingsAccount.displayDetails();
        savingsAccount.calculateAndAddInterest();
        savingsAccount.displayDetails();
        System.out.println("\n");

        System.out.println("Current Account Details:");
        currentAccount.displayDetails();
        System.out.println("\n");

        System.out.println("Fixed Deposit Account Details:");
        fixedDepositAccount.displayDetails();
    }
}
