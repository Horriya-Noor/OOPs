/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package studentfilehandling;

/**
 *
 * @author HP
 */

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class StudentFileHandling { 


    public static void main(String[] args) {
      
        String fileName = "student_records.txt";

      
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
           
            Scanner scanner = new Scanner(System.in);

            System.out.println("Enter student records (name, ID, CGPA). Enter 'done' to finish:");

            while (true) {
                System.out.print("Enter student name: ");
                String name = scanner.nextLine();

                if (name.equalsIgnoreCase("done")) {
                    break; 
                }

                System.out.print("Enter student ID: ");
                String id = scanner.nextLine();

                System.out.print("Enter student CGPA: ");
                double cgpa = scanner.nextDouble();
                scanner.nextLine(); 

                writer.write(name + "," + id + "," + cgpa + "\n");
                System.out.println("Student record added.");
            }

            scanner.close();

            System.out.println("Student records have been saved to " + fileName);

        } catch (IOException e) {
 
            System.err.println("Error writing to the file: " + e.getMessage());
        }
    }
}
