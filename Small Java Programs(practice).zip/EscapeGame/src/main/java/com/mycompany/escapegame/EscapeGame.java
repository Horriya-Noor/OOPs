
package com.mycompany.escapegame;

import java.util.Scanner;

public class EscapeGame {
   
    public static void main(String[] args) {
                
        Scanner scanner = new Scanner(System.in);
  
        String[] mysteryWords = {"POWER", "WILL", "EXPLOSION"};
        String[] quotes = {"Power is authority", "Will is the way to success", "Explosion is power"};


        for (int i = 0; i < mysteryWords.length; i++) {
            System.out.println("Room " + (i + 1) + ": Guess the word starting with " + mysteryWords[i].charAt(0));

            boolean correctGuess = false;

            do {
   
                System.out.print("Enter your guess: ");
                String guess = scanner.nextLine().toUpperCase();

                if (guess.equals(mysteryWords[i])) {
                    correctGuess = true;
                    System.out.println(quotes[i]);
                } else {
                    System.out.println("Incorrect. Try again.\n");
                }
            } while (!correctGuess);
        }
        System.out.println("Congratulations! You have escaped the haunted house.");
        scanner.close();
    }
}


