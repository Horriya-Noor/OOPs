/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.horriyatask2;

import java.util.Scanner;

public class HorriyaTask2 {

    // Class representing a cylinder
    public static class Cylinder {
        private double radius;
        private double height;

        // Constructor to initialize the radius and height of the cylinder
        public Cylinder(double radius, double height) {
            this.radius = radius;
            this.height = height;
        }

        // Method to display a welcome message
        public void displayMessage() {
            System.out.println("Welcome to the Cylinder Calculator!");
        }

        // Method to display the dimensions of the cylinder
        public void displayDimensions() {
            System.out.println("Radius: " + radius);
            System.out.println("Height: " + height);
        }

        // Method to calculate the base area of the cylinder
        public double calculateBaseArea() {
            return Math.PI * radius * radius;
        }

        // Method to calculate the volume of the cylinder
        public double calculateVolume() {
            return calculateBaseArea() * height;
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get the radius and height from the user
        System.out.print("Enter the radius of the cylinder: ");
        double radius = scanner.nextDouble();
        System.out.print("Enter the height of the cylinder: ");
        double height = scanner.nextDouble();

        // Create a Cylinder object using the provided inputs
        Cylinder cylinder = new Cylinder(radius, height);

        // Perform calculations and display results
        cylinder.displayMessage();
        cylinder.displayDimensions();

        double baseArea = cylinder.calculateBaseArea();
        double volume = cylinder.calculateVolume();

        System.out.println("Base Area: " + baseArea);
        System.out.println("Volume: " + volume);

        scanner.close(); // Close the scanner to prevent resource leaks.
    }
}
