/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package filehandling;

/**
 *
 * @author HP
 */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileHandling {
    public static void main(String[] args) {
        // Step 1: Create a File object with the desired file name or path
        File file = new File("data.txt");

        try {
            // Writing initial data to the file
            FileWriter writer = new FileWriter(file);
            writer.write("64048\n"); // Writing a sample integer as a string to the file
            writer.close();

            // Step 2: Use BufferedReader to read the data from the file
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;

            // Read the line from the file
            if ((line = reader.readLine()) != null) {
                // Add some information to the string
                String additionalInfo = line + " is the number read from the file.";

                // Convert the string to an integer
                int number = Integer.parseInt(line);
                
                // Output the results
                System.out.println("Read number: " + number);
                System.out.println("Additional Info: " + additionalInfo);
            }

            // Close the reader
            reader.close();
        } catch (IOException e) {
            // Handle potential IOException
            System.err.println("An IOException occurred: " + e.getMessage());
        } catch (NumberFormatException e) {
            // Handle potential NumberFormatException
            System.err.println("Error parsing integer: " + e.getMessage());
        }
    }
}
